from Components.Converter.Converter import Converter
from Components.Element import cached
from enigma import iServiceInformation, eServiceCenter, eServiceReference
from ServiceReference import ServiceReference

class MetrixHDServInfo(Converter):
    # Define types for the converter
    SERVICENAME = 0
    SERVICEREFERENCE = 1
    PROVIDER = 2
    NAMESPACE = 3
    VIDEO_PID = 4
    AUDIO_PID = 5
    PCR_PID = 6
    PMT_PID = 7
    TXT_PID = 8
    TSID = 9
    ONID = 10
    SID = 11
    VIDEO_CODEC = 12
    TRANSPONDER_TYPE = 13
    FREQUENCY = 14
    SYMBOLRATE = 15
    MODULATION = 16
    FEC = 17
    POLARIZATION = 18
    ORBITAL_POSITION = 19
    ECM_PID = 20
    SUBTITLE_INFO = 21
    AUDIO_CODEC = 22
    HDR_GAMMA = 2
    AUDIO_LANGUAGE = 24
    AUDIO_CHANNELS = 25

    def __init__(self, type):
        Converter.__init__(self, type)
        self.type = {
            "ServiceName": self.SERVICENAME,
            "ServiceReference": self.SERVICEREFERENCE,
            "Provider": self.PROVIDER,
            "Namespace": self.NAMESPACE,
            "VideoPID": self.VIDEO_PID,
            "AudioPID": self.AUDIO_PID,
            "PCRPID": self.PCR_PID,
            "PMTPID": self.PMT_PID,
            "TXTPID": self.TXT_PID,
            "TSID": self.TSID,
            "ONID": self.ONID,
            "SID": self.SID,
            "VideoCodec": self.VIDEO_CODEC,
            "TransponderType": self.TRANSPONDER_TYPE,
            "Frequency": self.FREQUENCY,
            "SymbolRate": self.SYMBOLRATE,
            "Modulation": self.MODULATION,
            "FEC": self.FEC,
            "Polarization": self.POLARIZATION,
            "OrbitalPosition": self.ORBITAL_POSITION,
            "ECMPIDs": self.ECM_PID,
            "SubtitleInfo": self.SUBTITLE_INFO,
            "AudioCodec": self.AUDIO_CODEC,
            "HDRGamma": self.HDR_GAMMA,
            "AudioLanguage": self.AUDIO_LANGUAGE,
            "AudioChannels": self.AUDIO_CHANNELS
        }.get(type, self.SERVICENAME)

    @cached
    def getText(self):
        service = self.source.service
        if not service:
            return ""

        info = service and service.info()
        if not info:
            return ""

        def formatHex(value):
            return f"0x{value:04X}" if value and isinstance(value, int) else "N/A"

        def getNamespace(value):
            if isinstance(value, str):
                return "N/A"
            namespace = f"{value & 0xFFFFFFFF:08X}"
            if namespace.startswith("EEEE"):
                return "DVB-T"
            elif namespace.startswith("FFFF"):
                return "DVB-C"
            else:
                position = int(namespace[:4], 16)
                alignment = "W" if position > 1800 else "E"
                position = 3600 - position if position > 1800 else position
                return f"{float(position) / 10.0}°{alignment}"

        def getServiceInfoValue(item):
            value = info.getInfo(item)
            if value == -2:
                value = info.getInfoString(item)
            elif value == -1:
                value = "N/A"
            return value

        if self.type == self.SERVICENAME:
            return ServiceReference(service).getServiceName() or "N/A"
        
        elif self.type == self.SERVICEREFERENCE:
            return service.toString() or "N/A"
        
        elif self.type == self.PROVIDER:
            return getServiceInfoValue(iServiceInformation.sProvider)
        
        elif self.type == self.NAMESPACE:
            return getNamespace(getServiceInfoValue(iServiceInformation.sNamespace))
        
        elif self.type == self.VIDEO_PID:
            return formatHex(getServiceInfoValue(iServiceInformation.sVideoPID))
        
        elif self.type == self.AUDIO_PID:
            audio = service.audioTracks()
            if audio and audio.getNumberOfTracks():
                track = audio.getCurrentTrack()
                if track >= 0:
                    return formatHex(audio.getTrackInfo(track).getPID())
            return "N/A"
        
        elif self.type == self.PCR_PID:
            return formatHex(getServiceInfoValue(iServiceInformation.sPCRPID))
        
        elif self.type == self.PMT_PID:
            return formatHex(getServiceInfoValue(iServiceInformation.sPMTPID))
        
        elif self.type == self.TXT_PID:
            return formatHex(getServiceInfoValue(iServiceInformation.sTXTPID))
        
        elif self.type == self.TSID:
            return formatHex(getServiceInfoValue(iServiceInformation.sTSID))
        
        elif self.type == self.ONID:
            return formatHex(getServiceInfoValue(iServiceInformation.sONID))
        
        elif self.type == self.SID:
            return formatHex(getServiceInfoValue(iServiceInformation.sSID))
        
        elif self.type == self.VIDEO_CODEC:
            from Components.Converter.PliExtraInfo import codec_data
            video_data = []
            video_data.append(codec_data.get(info.getInfo(iServiceInformation.sVideoType), "N/A"))
            width = info.getInfo(iServiceInformation.sVideoWidth)
            height = info.getInfo(iServiceInformation.sVideoHeight)
            if width > 0 and height > 0:
                video_data.append(f"{width}x{height}")
                video_data.append(f"{(info.getInfo(iServiceInformation.sFrameRate) + 500) // 1000}{('i', 'p', '')[info.getInfo(iServiceInformation.sProgressive)]}")
                video_data.append(f"[{'4:3' if getServiceInfoValue(iServiceInformation.sAspect) in (1, 2, 5, 6, 9, 0xA, 0xD, 0xE) else '16:9'}]")
            gamma = ("SDR", "HDR", "HDR10", "HLG", "")[info.getInfo(iServiceInformation.sGamma)]
            if gamma:
                video_data.append(gamma)
            return " - ".join(video_data) or "Unknown"
        
        elif self.type == self.TRANSPONDER_TYPE:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data:
                    return data.get("tuner_type", "N/A")
            return "N/A"
        
        elif self.type == self.FREQUENCY:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data:
                    tuner_type = data.get("tuner_type", "")
                    freq = data.get("frequency", 0)
                    if tuner_type == "DVB-C":
                        return f"{freq / 1000.0:.3f} MHz"
                    elif tuner_type == "DVB-S":
                        return f"{freq // 1000} MHz"
                    elif tuner_type in ("DVB-T", "ATSC"):
                        return f"{freq / 1000000.0:.3f} MHz"
            return "N/A"
        
        elif self.type == self.SYMBOLRATE:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data and data.get("tuner_type") in ("DVB-C", "DVB-S"):
                    return f"{data.get('symbol_rate', 0) // 1000} KSymb/s"
            return "N/A"
        
        elif self.type == self.MODULATION:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data:
                    return data.get("modulation", "N/A")
            return "N/A"
        
        elif self.type == self.FEC:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data:
                    return data.get("fec_inner", "N/A")
            return "N/A"
        
        elif self.type == self.POLARIZATION:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data and data.get("tuner_type") == "DVB-S":
                    return data.get("polarization", "N/A")
            return "N/A"
        
        elif self.type == self.ORBITAL_POSITION:
            frontend = service.frontendInfo()
            if frontend:
                data = frontend.getAll(True)
                if data and data.get("tuner_type") == "DVB-S":
                    return data.get("orbital_position", "N/A")
            return "N/A"
        
        elif self.type == self.ECM_PID:
            from Tools.GetEcmInfo import getCaidData, GetEcmInfo
            ecm_data = GetEcmInfo().getEcmData()
            caids = sorted(set(info.getInfoObject(iServiceInformation.sCAIDPIDs)), key=lambda x: (x[0], x[1]))
            result = []
            for caid in caids:
                description = "Undefined"
                for caid_entry in getCaidData():
                    if int(caid_entry[0], 16) <= caid[0] <= int(caid_entry[1], 16):
                        description = caid_entry[2]
                        break
                active = " (Active)" if caid[0] == int(ecm_data[1], 16) and (caid[1] == int(ecm_data[3], 16) or str(int(ecm_data[2], 16)) in caid[2]) else ""
                result.append(f"{formatHex(caid[1])}: {formatHex(caid[0])}-{description}{active}")
            return ", ".join(result) or "N/A"
        
        elif self.type == self.SUBTITLE_INFO:
            subtitle = service.subtitle()
            sub_list = subtitle and subtitle.getSubtitleList() or []
            subtitle_types = {
                0: "Unknown",
                1: "Embedded",
                2: "SSA file",
                3: "ASS file",
                4: "SRT file",
                5: "VOB file",
                6: "PGS file",
                7: "WebVTT"
            }
            subtitle_selected = subtitle and subtitle.getCachedSubtitle()
            if subtitle_selected:
                subtitle_selected = subtitle_selected[:3]
            result = []
            for sub in sub_list:
                indent = "(Current)" if sub[:3] == subtitle_selected else ""
                sub_lang = sub[4] or "Undefined"
                if sub[0] == 0:  # DVB PID
                    result.append(f"DVB: {formatHex(sub[1])} - {sub_lang} {indent}")
                elif sub[0] == 1:  # Teletext
                    result.append(f"TXT: 0x0{sub[3] or 8:X}{sub[2]:02X} - {sub_lang} {indent}")
                elif sub[0] == 2:  # File
                    sub_desc = subtitle_types.get(sub[2], f"Unknown: {sub[2]}")
                    result.append(f"Other: {sub[1] + 1} - {sub_desc} - {sub_lang} {indent}")
            return ", ".join(result) or "N/A"
        
        elif self.type == self.AUDIO_CODEC:
            audio = service.audioTracks()
            if audio and audio.getNumberOfTracks():
                track = audio.getCurrentTrack()
                if track >= 0:
                    return audio.getTrackInfo(track).getDescription() or "N/A"
            return "N/A"
        
        elif self.type == self.HDR_GAMMA:
            gamma = ("SDR", "HDR", "HDR10", "HLG", "")[info.getInfo(iServiceInformation.sGamma)]
            return gamma or "N/A"
        
        elif self.type == self.AUDIO_LANGUAGE:
            audio = service.audioTracks()
            if audio and audio.getNumberOfTracks():
                track = audio.getCurrentTrack()
                if track >= 0:
                    return audio.getTrackInfo(track).getLanguage() or "Undefined"
            return "N/A"
        
        elif self.type == self.AUDIO_CHANNELS:
            audio = service.audioTracks()
            if audio and audio.getNumberOfTracks():
                track = audio.getCurrentTrack()
                if track >= 0:
                    description = audio.getTrackInfo(track).getDescription().lower()
                    if "stereo" in description or "2.0" in description:
                        return "Stereo"
                    elif "5.1" in description or "dolby" in description or "dts" in description:
                        return "5.1"
                    elif "mono" in description or "1.0" in description:
                        return "Mono"
                    elif "7.1" in description:
                        return "7.1"
                    else:
                        return "Unknown"
            return "N/A"
        
        return ""

    text = property(getText)