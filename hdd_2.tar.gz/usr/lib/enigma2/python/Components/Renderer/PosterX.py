from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer, loadJPG, eEPGCache
from ServiceReference import ServiceReference
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.CurrentService import CurrentService
from Components.Sources.EventInfo import EventInfo
from Components.Sources.Event import Event
from Components.Renderer.PosterXDownloadThread import PosterXDownloadThread

import NavigationInstance
import os
import sys
import re
import time
import unicodedata

PY3 = (sys.version_info[0] == 3)
try:
    if PY3:
        import queue
        from _thread import start_new_thread
    else:
        import Queue
        from thread import start_new_thread
except:
    pass

epgcache = eEPGCache.getInstance()

try:
    from Components.config import config
    lng = config.osd.language.value
except:
    lng = None
    pass

apdb = dict()

# SET YOUR PREFERRED BOUQUET FOR AUTOMATIC POSTER GENERATION
autobouquet_file = '/etc/enigma2/userbouquet.favourites.tv'
autobouquet_count = 85

# Short script for Automatic poster generation on your preferred bouquet
if not os.path.exists(autobouquet_file):
    autobouquet_file = None
    autobouquet_count = 0
else:
    with open(autobouquet_file, 'r') as f:
        lines = f.readlines()
    if autobouquet_count > len(lines):
        autobouquet_count = len(lines)
    for i in range(autobouquet_count):
        if '#SERVICE' in lines[i]:
            line = lines[i][9:].strip().split(':')
            if len(line) == 11:
                value = ':'.join((line[3], line[4], line[5], line[6]))
                if value != '0:0:0:0':
                    service = ':'.join((line[0], line[1], line[2], line[3], line[4], line[5], line[6], line[7], line[8], line[9], line[10]))
                    apdb[i] = service

# Define poster storage path with UTF-8 support
path_folder = ""
if os.path.isdir("/media/hdd"):
    path_folder = "/media/hdd/poster/"
elif os.path.isdir("/media/usb"):
    path_folder = "/media/usb/poster/"
else:
    path_folder = "/tmp/poster/"
if not os.path.isdir(path_folder):
    os.makedirs(path_folder)

# Regex to clean text for filenames
REGEX = re.compile(
    r'\s\*\d{4}\Z|'  # remove ( *1234)
    r'([\(\[\|].*?[\)\]\|])|'  # remove ([xxx] or (xxx) or |xxx|)
    r'(\.\s{1,}\").+|'  # remove (. "xxx)
    r'(\?\s{1,}\").+|'  # remove (? "xxx)
    r'(\.{2,}\Z)',  # remove (..)
    re.DOTALL)

def convtext(text):
    """
    Clean text for filename usage while preserving multilingual characters.
    Supports Arabic, Cyrillic, Chinese, and other scripts.
    """
    text = text.replace('\xc2\x86', '').replace('\xc2\x87', '')
    text = REGEX.sub('', text)
    text = re.sub(r'[<>:"/\\|?*]', ' ', text)  # Replace invalid filename chars
    text = re.sub(r'\s{1,}', ' ', text)  # Replace multiple spaces with one
    text = text.strip().lower()
    
    # Ensure text is UTF-8 encoded for compatibility
    if isinstance(text, str):
        text = text.encode('utf-8').decode('utf-8')
    return text[:100]  # Limit filename length to avoid filesystem issues

if PY3:
    pdb = queue.LifoQueue()
else:
    pdb = Queue.LifoQueue()

class PosterDB(PosterXDownloadThread):
    def __init__(self):
        PosterXDownloadThread.__init__(self)
        self.logdbg = True  # Enable logging for debugging

    def run(self):
        self.logDB("[QUEUE] : Initialized")
        while True:
            canal = pdb.get()
            self.logDB("[QUEUE] : {} : {}-{} ({})".format(canal[0], canal[1], canal[2], canal[5]))
            dwn_poster = os.path.join(path_folder, canal[5] + ".jpg")
            if os.path.exists(dwn_poster):
                os.utime(dwn_poster, (time.time(), time.time()))
            
            # Language-specific search logic
            if lng == "fr_FR":  # French
                if not os.path.exists(dwn_poster):
                    val, log = self.search_molotov_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                    self.logDB(log)
                if not os.path.exists(dwn_poster):
                    val, log = self.search_programmetv_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng.startswith("ar_"):  # Arabic
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])  # Use original event name
                    self.logDB(log)
            elif lng == "uk_UA":  # Ukrainian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "ro_RO":  # Romanian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "sq_AL":  # Albanian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "de_DE":  # German
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "ru_RU":  # Russian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng.startswith("fa_"):  # Persian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "en_US" or lng == "en_GB":  # English
                if not os.path.exists(dwn_poster):
                    val, log = self.search_imdb(dwn_poster, canal[5], canal[4], canal[3])
                    self.logDB(log)
            elif lng == "es_ES":  # Spanish
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "pt_PT":  # Portuguese
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "ca_ES":  # Catalan
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "el_GR":  # Greek
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "it_IT":  # Italian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "hu_HU":  # Hungarian
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "sk_SK":  # Slovak
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "nl_NL":  # Dutch
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "nl_BE":  # Flemish
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "tr_TR":  # Turkish
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "zh_CN":  # Chinese
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "ja_JP":  # Japanese
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "ko_KR":  # Korean
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "hi_IN":  # Hindi
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            elif lng == "cs_CZ":  # Czech
                if not os.path.exists(dwn_poster):
                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                    self.logDB(log)
            
            # General search for all languages
            if not os.path.exists(dwn_poster):
                val, log = self.search_imdb(dwn_poster, canal[5], canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_poster):
                val, log = self.search_tmdb(dwn_poster, canal[5], canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_poster):
                val, log = self.search_tvdb(dwn_poster, canal[5], canal[4], canal[3])
                self.logDB(log)
            if not os.path.exists(dwn_poster):
                val, log = self.search_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                self.logDB(log)
            
            pdb.task_done()

    def logDB(self, logmsg):
        if self.logdbg:
            try:
                with open(os.path.join(path_folder, "PosterDB.log"), "a+", encoding='utf-8') as w:
                    w.write(f"{logmsg}\n")
            except Exception as e:
                print(f"[PosterDB] Log error: {e}")

threadDB = PosterDB()
threadDB.start()

class PosterAutoDB(PosterXDownloadThread):
    def __init__(self):
        PosterXDownloadThread.__init__(self)
        self.logdbg = True

    def run(self):
        self.logAutoDB("[AutoDB] *** Initialized")
        while True:
            time.sleep(7200)  # Run every 2 hours
            self.logAutoDB("[AutoDB] *** Running ***")
            
            # AUTO ADD NEW FILES
            for service in apdb.values():
                try:
                    events = epgcache.lookupEvent(['IBDCTESX', (service, 0, -1, 1440)])
                    newfd = 0
                    newcn = None
                    for evt in events:
                        canal = [None, None, None, None, None, None]
                        canal[0] = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                        if evt[1] is None or evt[4] is None or evt[5] is None or evt[6] is None:
                            self.logAutoDB("[AutoDB] *** missing epg for {}".format(canal[0]))
                        else:
                            canal[1] = evt[1]
                            canal[2] = evt[4]
                            canal[3] = evt[5]
                            canal[4] = evt[6]
                            canal[5] = convtext(canal[2])
                            dwn_poster = os.path.join(path_folder, canal[5] + ".jpg")
                            if os.path.exists(dwn_poster):
                                os.utime(dwn_poster, (time.time(), time.time()))
                            
                            # Language-specific search
                            if lng == "fr_FR":  # French
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_molotov_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_programmetv_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng.startswith("ar_"):  # Arabic
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "uk_UA":  # Ukrainian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "ro_RO":  # Romanian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "sq_AL":  # Albanian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "de_DE":  # German
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "ru_RU":  # Russian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng.startswith("fa_"):  # Persian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "en_US" or lng == "en_GB":  # English
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_imdb(dwn_poster, canal[5], canal[4], canal[3])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "es_ES":  # Spanish
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "pt_PT":  # Portuguese
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "ca_ES":  # Catalan
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "el_GR":  # Greek
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "it_IT":  # Italian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "hu_HU":  # Hungarian
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "sk_SK":  # Slovak
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "nl_NL":  # Dutch
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "nl_BE":  # Flemish
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "tr_TR":  # Turkish
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "zh_CN":  # Chinese
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "ja_JP":  # Japanese
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "ko_KR":  # Korean
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "hi_IN":  # Hindi
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            elif lng == "cs_CZ":  # Czech
                                if not os.path.exists(dwn_poster):
                                    val, log = self.search_google(dwn_poster, canal[2], canal[4], canal[3], canal[0])
                                    if val and "SUCCESS" in log:
                                        newfd += 1
                            
                            # General search
                            if not os.path.exists(dwn_poster):
                                val, log = self.search_imdb(dwn_poster, canal[5], canal[4], canal[3])
                                if val and "SUCCESS" in log:
                                    newfd += 1
                            if not os.path.exists(dwn_poster):
                                val, log = self.search_tmdb(dwn_poster, canal[5], canal[4], canal[3])
                                if val and "SUCCESS" in log:
                                    newfd += 1
                            if not os.path.exists(dwn_poster):
                                val, log = self.search_tvdb(dwn_poster, canal[5], canal[4], canal[3])
                                if val and "SUCCESS" in log:
                                    newfd += 1
                            if not os.path.exists(dwn_poster):
                                val, log = self.search_google(dwn_poster, canal[5], canal[4], canal[3], canal[0])
                                if val and "SUCCESS" in log:
                                    newfd += 1
                            newcn = canal[0]
                        self.logAutoDB("[AutoDB] {} new file(s) added ({})".format(newfd, newcn))
                except Exception as e:
                    self.logAutoDB("[AutoDB] *** service error : {} ({})".format(service, e))
            
            # AUTO REMOVE OLD FILES
            now_tm = time.time()
            emptyfd = 0
            oldfd = 0
            for f in os.listdir(path_folder):
                file_path = os.path.join(path_folder, f)
                diff_tm = now_tm - os.path.getmtime(file_path)
                if diff_tm > 120 and os.path.getsize(file_path) == 0:  # Empty files > 2 minutes
                    os.remove(file_path)
                    emptyfd += 1
                if diff_tm > 259200:  # Files > 3 days
                    os.remove(file_path)
                    oldfd += 1
            self.logAutoDB("[AutoDB] {} old file(s) removed".format(oldfd))
            self.logAutoDB("[AutoDB] {} empty file(s) removed".format(emptyfd))
            self.logAutoDB("[AutoDB] *** Stopping ***")

    def logAutoDB(self, logmsg):
        if self.logdbg:
            try:
                with open(os.path.join(path_folder, "PosterXBD.log"), "a+", encoding='utf-8') as w:
                    w.write(f"{logmsg}\n")
            except Exception as e:
                print(f"[PosterAutoDB] Log error: {e}")

threadAutoDB = PosterAutoDB()
threadAutoDB.start()

class PosterX(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        self.nxts = 0
        self.canal = [None, None, None, None, None, None]
        self.oldCanal = None
        self.logdbg = True
        if not self.intCheck():
            return
        self.timer = eTimer()
        self.timer.callback.append(self.showPoster)

    def applySkin(self, desktop, parent):
        attribs = []
        for (attrib, value) in self.skinAttributes:
            if attrib == "nexts":
                self.nxts = int(value)
            attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def intCheck(self):
        sock = False
        try:
            import socket
            socket.setdefaulttimeout(0.5)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            sock = True
        except:
            sock = False
        return sock

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.instance:
            return
        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
        if what[0] != self.CHANGED_CLEAR:
            servicetype = None
            try:
                service = None
                if isinstance(self.source, ServiceEvent):
                    service = self.source.getCurrentService()
                    servicetype = "ServiceEvent"
                elif isinstance(self.source, CurrentService):
                    service = self.source.getCurrentServiceRef()
                    servicetype = "CurrentService"
                elif isinstance(self.source, EventInfo):
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                    servicetype = "EventInfo"
                elif isinstance(self.source, Event):
                    if self.nxts:
                        service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                    else:
                        self.canal[0] = None
                        self.canal[1] = self.source.event.getBeginTime()
                        self.canal[2] = self.source.event.getEventName()
                        self.canal[3] = self.source.event.getExtendedDescription()
                        self.canal[4] = self.source.event.getShortDescription()
                        self.canal[5] = convtext(self.canal[2])
                    servicetype = "Event"
                if service:
                    events = epgcache.lookupEvent(['IBDCTESX', (service.toString(), 0, -1, -1)])
                    self.canal[0] = ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
                    self.canal[1] = events[self.nxts][1]
                    self.canal[2] = events[self.nxts][4]
                    self.canal[3] = events[self.nxts][5]
                    self.canal[4] = events[self.nxts][6]
                    self.canal[5] = convtext(self.canal[2])
                    if not autobouquet_file:
                        if self.canal[0] not in apdb:
                            apdb[self.canal[0]] = service.toString()
            except Exception as e:
                self.logPoster(f"Error (service): {e}")
                self.instance.hide()
                return
            if not servicetype:
                self.logPoster("Error: service type undefined")
                self.instance.hide()
                return
            try:
                curCanal = f"{self.canal[1]}-{self.canal[2]}"
                if curCanal == self.oldCanal:
                    return
                self.oldCanal = curCanal
                self.logPoster(f"Service: {servicetype} [{self.nxts}] : {self.canal[0]} : {self.oldCanal}")
                pstrNm = os.path.join(path_folder, self.canal[5] + ".jpg")
                if os.path.exists(pstrNm):
                    self.timer.start(100, True)
                else:
                    canal = self.canal[:]
                    pdb.put(canal)
                    start_new_thread(self.waitPoster, ())
            except Exception as e:
                self.logPoster(f"Error (eFile): {e}")
                self.instance.hide()
                return

    def showPoster(self):
        self.instance.hide()
        if self.canal[5]:
            pstrNm = os.path.join(path_folder, self.canal[5] + ".jpg")
            if os.path.exists(pstrNm):
                self.logPoster(f"[LOAD : showPoster] {pstrNm}")
                self.instance.setPixmap(loadJPG(pstrNm))
                self.instance.setScale(2)
                self.instance.show()

    def waitPoster(self):
        self.instance.hide()
        if self.canal[5]:
            pstrNm = os.path.join(path_folder, self.canal[5] + ".jpg")
            loop = 180
            found = None
            self.logPoster(f"[LOOP : waitPoster] {pstrNm}")
            while loop >= 0:
                if os.path.exists(pstrNm):
                    if os.path.getsize(pstrNm) > 0:
                        loop = 0
                        found = True
                time.sleep(0.5)
                loop -= 1
            if found:
                self.timer.start(10, True)

    def logPoster(self, logmsg):
        if self.logdbg:
            try:
                with open(os.path.join(path_folder, "PosterX.log"), "a+", encoding='utf-8') as w:
                    w.write(f"{logmsg}\n")
            except Exception as e:
                print(f"[PosterX] Log error: {e}")